public interface IEmploye{
    public String affiche();
    public void compare();
}