import java.time.LocalDate;

public class Employe implements IEmploye{
   
    private int id;
    private int id_service;
    public int getId_service() {
        return this.id_service;
    }

    public void setId_service(int id_service) {
        this.id_service = id_service;
    }

    private String nomComplet;
    private LocalDate dateEmbauche;
    

    
    private static int nbreEmpl;
    
   
        private Service service = new Service();
    
        public Service getService() {
            return service;
        }
    
        public void setService(Service service) {
            this.service = service;
            service.setTabEmploye(this);
        }

    
        
        public Employe(){
            nbreEmpl++;
        
            id=nbreEmpl;
        
        }

        
        public Employe(String nomComplet, LocalDate dateEmbauche, ){
            nbreEmpl++;
            id=nbreEmpl;
        setNomComplet(nomComplet);
        setDateEmbauche(dateEmbauche);
        
        }
        
        
        public int getId(){
            return id;
        }
        public String getNomComplet(){
            return nomComplet;
        }
        public LocalDate getDateEmbauche(){
            return dateEmbauche;
        }
       
        }
        public static int getNbreEmpl(){
            return nbreEmpl;
        }

        
        public void setId(int id){
            this.id=id;
        }
        public void setNomComplet(String nomComplet){
            this.nomComplet=nomComplet;
        }
        public void setDateEmbauche(LocalDate dateEmbauche){
            this.dateEmbauche=dateEmbauche;
        }
        
        }
        public static void setNbreEmpl(int nbreEmpl){
            Employe.nbreEmpl=nbreEmpl;
        }
       
        @Override
        public String affiche(){
            return "Id: "+id+"\nNom Complet: "+nomComplet+"\nDate d'embauche : ""\n";

        }
        public void compare(){

        }
}