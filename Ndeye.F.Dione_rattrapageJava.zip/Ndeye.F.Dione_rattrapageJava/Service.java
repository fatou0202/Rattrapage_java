public class Service implements IEmploye{
    
    private int id;
    private String libelle;

    
    private static int nbreServ;
    
    private Employe[] tabEmploye = new Employe[5];
    private int nbreEmploye;

    
        
        public Service(){
            nbreServ++;
        
            id=nbreServ;
        
        }

        
        public Service(String libelle){
            nbreServ++;
            id=nbreServ;
        setLibelle(libelle);
        }

      
        public int getId(){
            return id;
        }
        public String getLibelle(){
            return libelle;
        }
        public static int getNbreServ(){
            return nbreServ;
        }
        public Employe[] getTabEmploye(){
            return tabEmploye;
        }
        
        public void setId(int id){
            this.id=id;
        }
        public void setLibelle(String libelle){
            this.libelle=libelle;
        }
        public static void setNbreServ(int nbreServ){
            Service.nbreServ=nbreServ;
        }

       
        public boolean setTabEmploye(Employe employe){
            tabEmploye[nbreEmploye] = employe;
            nbreEmploye++;
            
            return true;
        }

      
        @Override
        public String affiche(){
            return "Id: "+id+"\nLibelle: "+libelle+ "\n";

        }
        public void compare(){
            
        }
}